# NOTE A — BUSINESS PAYROLL INVESTIGATION

**Question:** [exact business question]
**Employee:** [redacted token]
**Run and period:** [payroll run; pay date; job/step]
**Status/confidence:** [Confirmed | Strong evidence | Hypothesis | Undetermined]

## Executive answer
[2–5 sentences: actual result, why it occurred, whether this agrees with evidenced plan rules, confidence, any data needed to confirm.]

## Verified facts and expected outcome
| Item | Observed | Expected / rule | Evidence |
|---|---|---|---|
| Contribution | ... | ... | [LOG...] |
| Match | ... | ... | [LOG...] [CODE...] |

## Employee transaction sequence
| Seq | Phase / job step | Event timestamp / effective date | Transaction | Before/input | Processing and reason | After/output | Evidence / certainty |
|---|---|---|---|---|---|---|---|

## Calculation / reconciliation
- [Input amount] × [confirmed plan rule] = [independently derived amount]; show rounding and limits.
- Match actually recorded: [...]; difference: [...].
- Unknown operands: [...]; do not fill with guesses.

## Root cause / explanation for business
- **What happened:** ...
- **Why:** ...
- **Should it have happened?** ...
- **Employee impact / affected payrolls:** [confirmed or unknown]

## Next action
[Correct plan configuration? Data validation? Payroll adjustment review? Code defect assessment? State what is authorized vs proposed.]

## Evidence reviewed
[List attached log filename + lines/records, matched program paragraphs/source paths; note release/version.]

## Missing / uncertain; verification requested
[Prior YTD? Enrollment effective date? Plan rule? Reversal? Run logs?]
