# Investigation evidence convention

## Evidence ledger
| ID | Claim | Evidence path/lines | Evidence type | Confidence | Missing input |
|---|---|---|---|---|---|
| E1 | ... | ... | Observed log / Source / Config / Computed | Confirmed/Probable/Unknown | ... |

## Transaction evidence
| Seq | Event ID | Timestamp | Raw log path:lines | Type | Amount/sign | Effective date | Prior state | Next state | Observed/inferred |
|---|---|---|---|---|---|---|---|---|---|

If no sequence number is available, explicitly note that timestamp order may differ from business processing order. For each numeric computation give formula, input source, precision and rounding.

## Confidence vocabulary
- Observed: directly present in supplied job log, DB2 row, trace, or source.
- Calculated: arithmetic derived from cited inputs, subject to stated rounding.
- Inferred: possible execution from code without runtime proof.
- Hypothesis: plausible cause requiring evidence.
- Not verified: data absent or inaccessible.

## Source search checklist
Main program, COPY name variants, SQL INCLUDE/DCLGEN, LINKAGE, called programs, JCL/PROC, DD/DSN, DB2 table names, effective-dated configuration, job logs and scheduler parameters. Case-insensitive member lookup; inspect all colliding names, do not select arbitrarily.
