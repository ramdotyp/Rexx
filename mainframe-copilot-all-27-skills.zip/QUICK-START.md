# Quick-start prompt recipes

All commands are example requests for **GitHub Copilot Chat Agent mode**. If `/skill-name` is not offered, use the explicit form `Use the skill named ...`. Replace bracketed placeholders, and attach or include local paths to authorized files.

## 1. Why is an employee's 401(k) match incorrect?

```text
Use the skill named payroll-run-investigator.
Business question: Why was employee [masked ID]'s employer 401(k) match [actual] rather than [expected]?
Run: [run ID, pay date, pay period, job/step]. Logs: [path(s) or attached files].
Follow all relevant transactions in actual processing sequence, including retro, reversal, reprocessing and YTD limits.
Trace to relevant COBOL, COPY, DB2 INCLUDE/DCLGEN, SQL, JCL and plan configuration, with path/line or event ID evidence.
Output two distinct notes:
1) Business Investigation — concise explanation, event ledger, calculation and verified root cause or hypotheses.
2) Technical Recommended Fix — affected code/paragraphs, suggested change or explicitly 'No program fix supported', risks and regression tests.
Do not change files or run jobs. Label observed vs inferred facts.
```

## 2. Replay an employee's processing

```text
Use employee-payroll-simulator for [masked employee ID] in [run ID]. Logs: [paths].
Construct a sequence-ordered ledger with transaction type, inputs, old state, source paragraph, new state, and evidence.
Do not claim a branch executed unless supported by logs/traces. Reconcile [specific calculation].
```

## 3. Find first divergence between production and QA

```text
Use production-qa-comparator. Production logs: [paths]. QA logs: [paths].
Compare employee [masked ID], equivalent pay periods and data/config versions.
Normalize transaction IDs carefully, show earliest verifiable divergence, source logic, and remaining unknowns.
```

## 4. Explain an existing COBOL program

```text
Use cobol-program-understanding for [PROGRAM-ID] currently open in VS Code.
Trace mainline and all business-significant PERFORM/CALL paths, COPY/REPLACING and EXEC SQL INCLUDE/DCLGEN, related JCL and DB2 tables.
Output execution walkthrough, rule inventory, data flows and source citations. Read only.
```

## 5. Draft functional specs

```text
Use functional-spec-generator for [PROGRAM-ID].
Explain inputs, outputs, validations, calculations, state transitions, SQL, business rules and exception paths.
Cite each rule to source and mark unverifiable requirements. Include testable acceptance scenarios.
```

## 6. Analyze proposed DB2 change

```text
Use db2-column-change-advisor for [SCHEMA.TABLE.COLUMN] from [old data type] to [new data type].
Inspect every reference, embedded SQL, host variable, DCLGEN, program interface and package/bind dependency.
Separate proven issues from possible risks; suggest change checklist and regression tests. No source edits.
```

## 7. Analyze production abend

```text
Use production-abend-analyzer for job [JOB], step [STEP], abend/SQLCODE [CODE].
Logs: [paths]. Find first causal failure (not just final abend), related source lines/data conditions and safe next checks.
```

## 8. Trace a suspicious field

```text
Use field-value-investigator for [PROGRAM.FIELD / TABLE.COLUMN].
Find source, all setters/readers, conditions, numeric conversions, resets, SQL and output sinks.
Show exact provenance and earliest suspected cause with source evidence.
```

## 9. Prepare for a code change

```text
Use change-request-translator and impact-analysis.
Business request: [description]. Identify impacted COBOL/JCL/DB2/COPY assets, edge cases and a test matrix.
Do not alter files. Distinguish verified dependencies from potential dynamic ones.
```

## 10. Review a patch

```text
Use cobol-change-verifier to review [changed files or git diff].
Check COBOL 6.2 PIC/USAGE, COMP-3/ROUNDED/truncation, DB2 SQLCODE/NULL, copybook interfaces and impacted business rules.
List findings with severity, evidence and suggested tests. Do not edit files.
```
