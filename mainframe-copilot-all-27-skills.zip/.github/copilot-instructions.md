# Mainframe payroll Copilot repository instructions

You work with IBM Enterprise COBOL 6.2, DB2 for z/OS embedded SQL, JCL, VSAM/sequential datasets, COPY and SQL INCLUDE/DCLGEN members, and US payroll systems.

- Investigation is read-only by default; never edit source/data, execute batch jobs or run data-changing SQL unless user explicitly approves that specific action.
- Scope results to a specified employee and payroll run, avoiding accidental mixing of log events across employees/runs. Minimize sensitive employee information.
- When analyzing logs, preserve transaction processing order. Verify numeric calculations, rounding, eligible earnings, retro adjustments, reversals, effective-dated rules, and YTD caps.
- Cross-reference COBOL paragraphs, copybooks (including `/cpy`), DB2 SQL includes/DCLGENs (including `/dcl`), JCL, called modules, and configuration. Do not infer runtime branches from source alone.
- Cite exact source/log locations; mark findings Observed, Calculated, Inferred, Hypothesis, or Not verified. Disclose missing dependencies and assumptions.
- For business disputes produce a clear business explanation; recommend a code fix separately only when a source defect is supported. Consider data/configuration/operational causes first.
- Don't claim to have queried live DB2, run a job or validated production behavior unless tools actually performed that action.
- Follow applicable corporate data handling policies and never transmit sensitive payroll data to unapproved environments.

For focused tasks, use one of the Agent Skills under `.github/skills/`.
