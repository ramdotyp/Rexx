# Mainframe Copilot Skills — Complete Library

**27 reusable GitHub Copilot Agent Skills** for IBM Enterprise COBOL 6.2, DB2 for z/OS, JCL, copybooks, DCLGENs, and US payroll analysis. This ZIP consolidates all earlier skill packages: 16 foundational, 10 advanced, and 1 dedicated employee payroll-run investigator.

## Install in your Bitbucket-backed VS Code workspace

1. Open the **root of your mainframe repository** in VS Code (the root that contains COBOL/JCL and related `/cpy` and `/dcl` directories). Confirm you are using your organization's approved GitHub Copilot and model configuration for payroll data.
2. Extract this ZIP to a temporary directory. Copy the entire **`.github/skills/`** directory into **`<repo-root>/.github/skills/`**, retaining the nested `SKILL.md` and `references` files. Do not paste all SKILL.md files into a single folder.
3. **Review and merge** the supplied `.github/copilot-instructions.md` into your existing file; do not overwrite existing organization instructions. The file contains shared read-only, evidence and privacy policies.
4. In VS Code, open **GitHub Copilot Chat → Agent mode**, select the available model (e.g., Claude Opus), and open the COBOL program you want to investigate. Allow the agent to read the relevant workspace paths. You may need to enable Agent Skills support in your organization/version of VS Code and restart the chat or reload the window after adding skills.
5. Select a skill using `/skill-name` **if available in the slash-command picker**, or type `Use the skill named <skill-name> to ...`. Verify Copilot names the skill and actually reads its `SKILL.md` rather than assuming it was invoked. Some Copilot versions or policies may not list skills as slash commands.
6. Provide the business question, run identifiers, log paths, expected/actual figures, and any plan/configuration details you have. Ask for source and log references in the answer. Skills are **read-only by default**; they should suggest code changes in a separate technical note, not apply them.

### Suggested repository structure

```text
repo-root/
├── cobol/
├── cpy/
├── dcl/
├── jcl/
└── .github/
    ├── copilot-instructions.md
    └── skills/
        ├── cobol-program-understanding/
        │   └── SKILL.md
        ├── payroll-run-investigator/
        │   ├── SKILL.md
        │   └── references/
        │       ├── business-investigation-template.md
        │       └── technical-fix-template.md
        └── ... 25 other skills
```

**Important:** IBM Z Open Editor copybook hover/Go to Definition navigation is an editor/language-server feature, not an Agent Skill. Configure `/cpy` and `/dcl` search paths separately in your COBOL editor/project settings.

## Which skill should I use?

### Understand and document

- **`cobol-program-understanding`** — Explain an IBM Enterprise COBOL 6.2 program end to end across paragraphs, copybooks, DB2 SQL, JCL, and called programs; use when onboarding or decoding legacy behavior.
- **`functional-spec-generator`** — Produce detailed, source-evidenced COBOL/DB2 functional specifications suitable for analysts, maintainers, and QA; use for documentation and change planning.
- **`business-rule-extractor`** — Extract and organize business rules from COBOL, DB2 SQL, JCL and copybooks into a traceable rule catalog, including eligibility, effective dates and calculation examples.
- **`application-knowledge-map`** — Build a navigable map of a mainframe repository: programs, CALL graph, tables, copybooks, jobs, files, and key business functions; use for onboarding.
- **`cross-program-flow-tracer`** — Trace business data and control flow across COBOL CALL chains, copybooks, batch steps, DB2 tables and files; build an evidence-based application map.
- **`data-lineage-tracker`** — Trace a field from origin to target through COBOL MOVE/COMPUTE, copybooks, DB2, files, and called programs; use for mapping, reconciliation or auditing.
- **`field-value-investigator`** — Explain why a COBOL or DB2 field has a particular value by tracing writes, resets, arithmetic, SQL results, copybook layouts and event ordering.

### Investigate payroll and production

- **`payroll-run-investigator`** — Investigate employee-specific payroll discrepancies from attached batch job logs and COBOL/DB2/JCL source. Reconstruct transaction order, explain observed calculations and business rules with evidence, and produce a separate technical recommended-fix note. Use for 401(k) match, deductions, benefits, taxes, gross/net, retro, and payroll adjustments.
- **`employee-payroll-simulator`** — Reconstruct and explain an employee payroll run from attached transaction logs, COBOL source, DB2 mappings and plan configuration; distinguish observed transactions from inferred execution.
- **`production-qa-comparator`** — Compare production and QA payroll runs for the same case, align transactions, find first divergence and explain source, data or configuration cause with evidence.
- **`payroll-variance-explainer`** — Reconcile differences between payroll runs or periods for an employee, including gross-to-net, deduction, tax, benefit and 401(k) differences with traceable arithmetic.
- **`payroll-calculation-auditor`** — Audit COBOL payroll business rules, wages, deductions, rounding, retroactivity, splits, limits and effective dates; use for high-assurance payroll analysis.
- **`effective-date-rule-auditor`** — Audit COBOL and DB2 effective-dated payroll rule selection, including plan enrollment, eligibility, rate, limits, retro dates and overlapping records.
- **`production-abend-analyzer`** — Investigate COBOL, JCL and DB2 production failures using logs, dumps, SQLCODEs, return codes and code paths; use for RCA without changing production.
- **`file-reconciliation-auditor`** — Investigate mismatches between batch input/output files, DB2 row counts, totals and control reports; use for balancing and reconciliation.
- **`restart-recovery-analyzer`** — Analyze batch restartability, checkpoint and commit semantics for COBOL/DB2/JCL workflows; use after interrupted jobs or when designing recovery.

### Change and test

- **`change-request-translator`** — Translate a business change request into source-linked COBOL/DB2 implementation scope and acceptance criteria without changing code; use for estimation and planning.
- **`impact-analysis`** — Analyze change impact across COBOL, copybooks, DCLGENs, DB2 tables, programs, JCL, and downstream interfaces; use before changing fields, rules or schemas.
- **`incident-to-fix-planner`** — Turn an evidence-backed payroll production incident into separate business RCA and technical remediation proposal, with alternatives, safety controls and regression plan.
- **`test-case-generator`** — Derive deterministic unit, integration, DB2 and batch regression cases from COBOL branches and business rules; use before releases or defect fixes.
- **`cobol-change-verifier`** — Review a proposed COBOL, copybook, SQL or JCL diff for behavioral changes, unintended side effects, precision issues and regression coverage without changing source.
- **`cobol-code-review`** — Perform read-only maintainability and correctness review of COBOL 6.2 changes, including DB2, data semantics and regression risk; use for peer review.
- **`copybook-interface-auditor`** — Analyze COBOL COPY members, DCLGENs, linkage parameter compatibility and record-layout changes; use when shared layouts or interfaces change.
- **`db2-column-change-advisor`** — Analyze DB2 for z/OS column definition changes and dependencies in COBOL, DCLGEN, SQL, bind packages and data movement; produce DBA/developer checklists with verified vs uncertain implications.

### DB2 and batch

- **`db2-sql-auditor`** — Audit embedded DB2 for z/OS SQL in COBOL for correctness, host-variable compatibility, cursor flow, SQLCODE handling, and transaction safety; use for SQL review.
- **`db2-performance-review`** — Review COBOL embedded DB2 queries for potential performance issues without guessing EXPLAIN plans; use for DB2 tuning investigations.
- **`jcl-job-analyzer`** — Explain a z/OS batch job from JCL through PROCs, SORT steps, datasets, return codes and COBOL executables; use for operational onboarding and job analysis.

## Common working patterns

**A. Business asks why employee 401(k) match is different.** Use `payroll-run-investigator`, supplying employee token, run/date/job ID, logs, actual value, expected value and the relevant plan rule. Request two **separate** outputs: business root cause and technical recommendation. If the logs have many transactions, use `employee-payroll-simulator` first to reconstruct the event ledger. If QA is different, use `production-qa-comparator` next.

**B. Understand an unfamiliar COBOL program.** Open the file and ask Copilot to use `cobol-program-understanding`; follow with `business-rule-extractor` or `functional-spec-generator`. Require copybook, SQL INCLUDE, called-program, and JCL references where relevant.

**C. Implement an approved business change.** Use `change-request-translator` → `impact-analysis` → `test-case-generator` → `cobol-change-verifier`. The skills propose and review changes, but do not modify production code or run tests unless separately authorized.

**D. DB2 schema change.** Use `db2-column-change-advisor` then `copybook-interface-auditor` and `impact-analysis` to inspect host variables, DCLGENs, SQL, package/bind and downstream effects. Distinguish required changes from environment-dependent ones.

## Interpretation and evidence rules

- A **COBOL source path** supports what code *can* do, not necessarily what production *did*. Logs, DB2 values, job version, or additional traces are needed for the actual path.
- For log-based payroll work, demand the exact sequence number/event ID/job-step and source line or paragraph for each material claim. If logs are incomplete, require hypotheses to be marked as hypotheses.
- Payroll plans differ: do not assume any universal employer-match formula or IRS limit. Check effective-dated plan configuration, eligible earnings, catch-ups, caps, reversals, YTD and true-ups.
- Keep personnel data within an approved workspace and minimize personally identifying data in notes.
- If the workspace includes multiple repos or dynamic dependencies, explicitly provide the relevant paths and note what Copilot could not inspect.

## Included supporting guides

- `QUICK-START.md`: copy/paste prompt recipes for common investigations.
- `PAYROLL-CASE-WALKTHROUGH.md`: complete employee-specific investigation workflow and deliverable templates.
- `SKILLS-INDEX.md`: alphabetical skill inventory and source package.
- `README.md`: this installation and usage guide.
